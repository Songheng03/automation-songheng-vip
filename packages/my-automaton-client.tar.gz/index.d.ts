declare class MyAutomatonClient {
  constructor(options?: { baseUrl?: string; apiKey?: string; freeTier?: boolean });
  analyze(text: string, options?: Record<string, any>): Promise<any>;
  summarize(text: string, options?: { maxLength?: number }): Promise<any>;
  review(code: string, options?: { language?: string }): Promise<any>;
  securityScan(code: string, options?: { language?: string }): Promise<any>;
  explain(code: string, options?: { language?: string }): Promise<any>;
  refactor(code: string, options?: { language?: string }): Promise<any>;
  analyzeComplexity(code: string, options?: { language?: string }): Promise<any>;
  batch(items: any[]): Promise<any>;
}
export = MyAutomatonClient;
export default MyAutomatonClient;
