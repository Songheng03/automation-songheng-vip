# my-automaton-client

JavaScript client for [my-automaton](https://automation.songheng.vip) AI API — code review, security scanning, text analysis, and more.

**Pay per request from $0.01** (or use the free tier: 3 requests/day/IP, no key needed).

## Features

- 🔍 **Code Review** — AI-powered code review with bug detection and best practices
- 🔒 **Security Scanning** — Vulnerability detection (SQL injection, XSS, etc.)
- 📝 **Text Analysis** — Deep text analysis with sentiment and key insights
- 📄 **Summarization** — AI-powered text summarization
- 💡 **Code Explanation** — Turn complex code into plain English
- 🔧 **Refactoring** — Get refactoring suggestions for your code
- 📊 **Complexity Analysis** — Cyclomatic and cognitive complexity analysis

## Installation

```bash
npm install my-automaton-client
```

## Quick Start (Free Tier — No API Key)

```javascript
const MyAutomaton = require('my-automaton-client');
const client = new MyAutomaton();

// Review code (free, 3/day)
const result = await client.review('function hello() { return "world"; }', { language: 'javascript' });
console.log(result);
```

## With API Key

```javascript
const client = new MyAutomaton({ apiKey: 'am_your_key_here' });

// Security scan
const scan = await client.securityScan(`<?php echo $_GET['id']; ?>`, { language: 'php' });
console.log(scan);
```

## Pricing

| Plan | Price | Credits | Use Case |
|------|-------|---------|----------|
| Starter | HK$38 (~$4.85) | 500 credits | Small projects |
| Advanced | HK$78 (~$9.95) | 1,100 credits | Regular use |
| Professional | HK$198 (~$25.27) | 3,000 credits | Professional |
| Ultimate | HK$388 (~$49.50) | 6,500 credits | Heavy usage |

Get your API key at [automation.songheng.vip/api-docs.html](https://automation.songheng.vip/api-docs.html)

## API Reference

All endpoints return JSON. Error responses include descriptive messages.

| Endpoint | Cost | Description |
|---|---|---|
| POST /v1/analyze | $0.01 | Deep text analysis |
| POST /v1/summarize | $0.02 | AI summarization |
| POST /v1/review | $0.05 | Full code review |
| POST /v1/security | $0.03 | Security vulnerability scan |
| POST /v1/explain | $0.02 | Code explanation |
| POST /v1/refactor | $0.05 | Refactoring suggestions |
| POST /v1/complexity | $0.02 | Complexity analysis |

## License

MIT
