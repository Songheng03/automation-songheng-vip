/**
 * my-automaton-client - JavaScript client for my-automaton AI API
 * 
 * Features: Code review, security scanning, text analysis, summarization, code explanation, refactoring
 * Website: https://automation.songheng.vip
 * API Docs: https://automation.songheng.vip/api-docs.html
 */

const BASE_URL = 'https://automation.songheng.vip';

class MyAutomatonClient {
  constructor(options = {}) {
    this.baseUrl = options.baseUrl || BASE_URL;
    this.apiKey = options.apiKey || null;
    this.freeTier = options.freeTier !== false;
  }

  _headers() {
    const headers = { 'Content-Type': 'application/json' };
    if (this.apiKey) headers['X-API-Key'] = this.apiKey;
    return headers;
  }

  async _request(endpoint, data) {
    const url = `${this.baseUrl}${endpoint}`;
    const res = await fetch(url, {
      method: 'POST',
      headers: this._headers(),
      body: JSON.stringify(data)
    });
    if (res.status === 402) {
      return { 
        error: 'Payment required', 
        message: 'You need an API key. Get one at https://automation.songheng.vip/api-docs.html',
        status: 402
      };
    }
    return res.json();
  }

  async getFreeInfo() { return { freePerDay: 3, remaining: 'Check /api/stats/free' }; }

  async analyze(text, options = {}) {
    return this._request('/v1/analyze', { text, ...options });
  }

  async summarize(text, options = {}) {
    return this._request('/v1/summarize', { text, maxLength: options.maxLength || 200 });
  }

  async review(code, options = {}) {
    return this._request('/v1/review', { code, language: options.language || 'javascript' });
  }

  async securityScan(code, options = {}) {
    return this._request('/v1/security', { code, language: options.language || 'javascript' });
  }

  async explain(code, options = {}) {
    return this._request('/v1/explain', { code, language: options.language || 'javascript' });
  }

  async refactor(code, options = {}) {
    return this._request('/v1/refactor', { code, language: options.language || 'javascript' });
  }

  async analyzeComplexity(code, options = {}) {
    return this._request('/v1/complexity', { code, language: options.language || 'javascript' });
  }

  async batch(items) {
    return this._request('/v1/batch', { items });
  }
}

module.exports = MyAutomatonClient;
module.exports.default = MyAutomatonClient;
